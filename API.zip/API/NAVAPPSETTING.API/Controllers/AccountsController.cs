﻿

using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using NAVAPPSETTING.DATA.Domain;
using NAVAPPSETTING.DATA.Models.AccountViewModels;
using NAVAPPSETTING.DATA;
using NAVAPPSETTING.API.Helpers;
using NAVAPPSETTING.DATA.Models;
using Framework.Core;
using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Security.Claims;
using System.Linq;

namespace NAVAPPSETTING.API.Controllers
{
    [Route("api/[controller]")]
    public class AccountsController : Controller
    {
        private readonly ApplicationDbContext _appDbContext;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        public AccountsController(UserManager<ApplicationUser> userManager, ApplicationDbContext appDbContext, SignInManager<ApplicationUser> _signInManager)
        {
            _userManager = userManager;

            _appDbContext = appDbContext;
            this._signInManager = _signInManager;
        }

        // POST api/accounts
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] RegisterViewModel model)
        {

            if (string.IsNullOrWhiteSpace(model.CompanyName))
            {
                throw new ApiException("Please input company name.");
            }
            if (string.IsNullOrWhiteSpace(model.FullName))
            {
                throw new ApiException("Please input full name.");
            }
            if (string.IsNullOrWhiteSpace(model.Password))
            {
                throw new ApiException("Please input password.");
            }
            if (string.IsNullOrWhiteSpace(model.Email))
            {
                throw new ApiException("Please input email.");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = new ApplicationUser { UserName = model.Email, Email = model.Email, FullName = model.FullName, CompanyName = model.CompanyName };

            var result = await _userManager.CreateAsync(user, model.Password);

            if (!result.Succeeded) return new BadRequestObjectResult(Errors.AddErrorsToModelState(result, ModelState));

            //   await _appDbContext.Customers.AddAsync(new Customer { IdentityId = userIdentity.Id, Location = model.Location });
            await _appDbContext.SaveChangesAsync();

            return new OkObjectResult("Account created");
        }
        [HttpPut]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> Put([FromBody] RegisterViewModel model)
        {
            if (string.IsNullOrWhiteSpace(model.CompanyName))
            {
                throw new ApiException("Please input company name.");
            }
            if (string.IsNullOrWhiteSpace(model.FullName))
            {
                throw new ApiException("Please input full name.");
            }
            if (string.IsNullOrWhiteSpace(model.Email))
            {
                throw new ApiException("Please input email.");
            }
            var user = await _userManager.FindByIdAsync(model.Id);
            user.FullName = model.FullName;
            user.CompanyName = model.CompanyName;
            user.NavUrl = model.NavUrl;
            await _appDbContext.SaveChangesAsync();

            return new OkObjectResult("Account updated");
        }
        [HttpGet("{id}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> Get(string id)
        {
            RegisterViewModel model = new RegisterViewModel();
            var useremail = _userManager.GetUserAsync(User).Result;
            var identity = User.Identity as ClaimsIdentity;
            var claims = from c in identity.Claims
                         select new
                         {
                             subject = c.Subject.Name,
                             type = c.Type,
                             value = c.Value
                         };

            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                throw new ApplicationException($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }
            model.FullName = user.FullName;
            model.CompanyName = user.CompanyName;
            model.Email = user.Email;
            model.NavUrl = user.NavUrl;
            model.Id = user.Id;
            return Ok(model);
        }
    }
}
