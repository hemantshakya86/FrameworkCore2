﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NAVAPPSETTING.DATA.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Logging;
using Framework.Repository;


using NAVAPPSETTING.DATA;

namespace NAVAPPSETTING.API.Services.Impl
{

    public class UnitOfWork :  IUnitOfWork
    {
        private readonly ApplicationDbContext weakContext;

       
        public UnitOfWork(ApplicationDbContext weakContext)
        {
            this.weakContext = weakContext;
        }
         
        public ApplicationDbContext Context
        {

            get
            {
                

                return weakContext;
            }
        }

        public int Commit()
        {
            var entities = weakContext.ChangeTracker.Entries().Where(x => x.Entity is AggregateEntity && (x.State == EntityState.Added || x.State == EntityState.Modified));

            foreach (var entity in entities)
            {
                if (entity.State == EntityState.Added)
                {

                    ((AggregateEntity)entity.Entity).CreateDate = DateTime.UtcNow;

                }
                if (entity.State == EntityState.Modified)
                {

                    ((AggregateEntity)entity.Entity).LastUpdatedDate = DateTime.UtcNow;


                }
            }
            return weakContext.SaveChanges();
        }
       
        public Task<int> CommitAsync()
        {
            return Task.Run(() => this.Commit());
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>
        ///     Async commits this object.
        /// </summary>
        ///
        /// <returns>
        ///     .
        /// </returns>
        ///-------------------------------------------------------------------------------------------------
        Task<int> IUnitOfWork.CommitAsync()
        {
            return this.CommitAsync();
        }








        ///-------------------------------------------------------------------------------------------------
        /// <summary>
        ///     Gets the Entity Repository.
        /// </summary>
        ///
        /// <typeparam name="TEntity">
        ///     Type of the entity.
        /// </typeparam>
        ///
        /// <returns>
        ///     Entity Repository.
        /// </returns>
        ///-------------------------------------------------------------------------------------------------
        public IRepository<TEntity> Get<TEntity>() where TEntity : class
        {

            Repository<TEntity> repository = new Repository<TEntity>(weakContext);

            return repository;
        }

        public void Rollback()
        {
            throw new NotImplementedException();
        }
        private static bool HasChanged(EntityEntry entity)
        {
            return IsState(entity, EntityState.Added) ||
                   IsState(entity, EntityState.Deleted) ||
                   IsState(entity, EntityState.Modified);
        }

        private static bool IsState(EntityEntry entity, EntityState state)
        {
            return (entity.State & state) == state;
        }
    }



}
