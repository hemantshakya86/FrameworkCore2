﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace NAVAPPSETTING.DATA.Domain
{
    public class ApplicationUser : IdentityUser
    {
       

        public string FullName { get; set; }
        public string CompanyName { get; set; }
        public string NavUrl { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsLockedOut => this.LockoutEnabled && this.LockoutEnd >= DateTimeOffset.UtcNow;


       
    }
}
