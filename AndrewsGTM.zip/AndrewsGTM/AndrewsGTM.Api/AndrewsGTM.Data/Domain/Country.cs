﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data;
using Framework.Repository;

namespace AndrewsGTM.Data.Domain
{
    public class Country : AggregateEntity<int>
    {
        /// <summary>
        /// To get  and set the Country Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// To get  and set the Country Abbreviated Name
        /// </summary>
        public string AbbreviatedName { get; set; }

        private EntityCollection<State> states;
        public virtual EntityCollection<State> States
        {
            get { return this.states ?? (this.states = this.CreateCollection<State>()); }
        }
    }
}
