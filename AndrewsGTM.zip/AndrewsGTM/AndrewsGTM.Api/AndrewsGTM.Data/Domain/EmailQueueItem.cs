﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data;
using Framework.Repository;

namespace AndrewsGTM.Data.Domain
{
    public class EmailQueueItem : Entity
    {
        public string Message { get; set; }

        public DateTime? SendDate { get; set; }

        public DateTime CreateDate { get; set; }

        public int RetryAttempt { get; set; }

        public string ErrorMessage { get; set; }
    }
}
