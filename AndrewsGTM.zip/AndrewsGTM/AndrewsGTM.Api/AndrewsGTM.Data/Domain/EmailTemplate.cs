﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data;
using Framework.Repository;

namespace AndrewsGTM.Data.Domain
{
    public class EmailTemplate : AggregateEntity<int>
    {
        /// <summary>
        /// Get or set the TemplateFor
        /// </summary>
        public EmailTemplateForType TemplateFor { get; set; }
        /// <summary>
        ///  Get or set the Message
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        ///  Get or set the Subject
        /// </summary>
        public string Subject { get; set; }

    }
}
