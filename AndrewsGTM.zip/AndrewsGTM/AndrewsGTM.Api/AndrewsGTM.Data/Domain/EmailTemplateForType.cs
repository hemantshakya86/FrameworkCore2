﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel;

namespace AndrewsGTM.Data.Domain
{

    public enum EmailTemplateForType
    {
        [Description("Forgot Password")]
        ForgotPassword = 0,

        [Description("Welcome")]
        Welcome = 1,
    }
}
