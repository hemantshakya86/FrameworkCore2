﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data;
using Framework.Repository;

namespace AndrewsGTM.Data.Domain
{
    public class InboxMessage : Entity
    {
        public Guid? FromID { get; set; }

        public Guid ToID { get; set; }

        public string FromName { get; set; }

        public string ToName { get; set; }

        public string Subject { get; set; }

        public string Message { get; set; }

        public string Priority { get; set; }

        public DateTime? SentDate { get; set; }

        public DateTime? ReadDate { get; set; }
       
      
    }
}
