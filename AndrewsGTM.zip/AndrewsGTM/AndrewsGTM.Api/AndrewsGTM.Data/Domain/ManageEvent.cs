﻿using Framework.Repository;
using AndrewsGTM.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AndrewsGTM.Data.Domain
{
    public class ManageEvent : AggregateEntity<int>
    {
        public string Name { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string ZipCode { get; set; }

        public DateTime? EventStartDate { get; set; }

        public DateTime? EventEndDate { get; set; }

        public string Logo { get; set; }

        public string DasboardImage { get; set; }

        public string LandingPageImage { get; set; }

        public string UniqueUrl { get; set; }

        public string EventManagerProfilePic { get; set; }

        public string EventManagerName { get; set; }

        public string EventManagerEmail { get; set; }
        //private EntityCollection<Ticket> tickets;
        //public virtual EntityCollection<Ticket> Tickets
        //{
        //    get { return this.tickets ?? (this.tickets = this.CreateCollection<Ticket>()); }
        //}

        //private EntityCollection<Reward> rewards;
        //public virtual EntityCollection<Reward> Rewards
        //{
        //    get { return this.rewards ?? (this.rewards = this.CreateCollection<Reward>()); }
        //}

    }
}
