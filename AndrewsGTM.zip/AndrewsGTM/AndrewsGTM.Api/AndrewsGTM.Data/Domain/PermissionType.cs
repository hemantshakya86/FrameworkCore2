﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AndrewsGTM.Data.Domain
{
    public enum PermissionType : int
    {
        [Description("Administration")]
        Administration = 1,

        [Description("View People Directory")]
        PeopleDirectory = 2,

        [Description("Impersonate User ")]
        UserImpersonate = 3,

        [Description("Edit User Profile")]
        EditProfile = 4,

        [Description("Institution Add / Edit")]
        InstitutionAdd = 6,

        [Description("View Institution")]
        InstitutionView = 7,

        [Description("View Institution Contact")]
        InstitutionContactView = 8,

        [Description("Edit Institution Contact")]
        InstitutionContactEdit = 9,
        [Description("View Site Visit History")]
        ViewSiteVisitHistory = 11,
        [Description("Edit Site visit History")]
        EditSitevisitHistory = 12,

        [Description("Program Add / Edit")]
        ProgramAdd = 13,

        [Description("View Program")]
        ProgramView = 14,

        [Description("View Program Contact")]
        ProgramContactView = 16,

        [Description("Program Contact Add / Edit")]
        ProgramContactAdd = 17,



        [Description("Add Self Study")]
        SelfStudyCreate = 19,

        //[Description("Self Study Submit / Response")]
        //SelfStudySubmit = 20,

        [Description("Self Study Review")]
        SelfStudyReview = 21,

        [Description("Self Study Submit / Response")]
        SelfStudyResponse = 22,

        [Description("Add/Edit Reviewers")]
        AddEditReviewers = 23,


        [Description("Self Study PDF Export")]
        SelfStudyPDFExport = 24,

        [Description("Add Site Visit")]
        SiteVisitCreate = 25,

        [Description("Site Visit Review")]
        SiteVisitReview = 26,

        [Description("Site Visit Response")]
        SiteVisitResponse = 27,
        [Description("Add/Edit Visitor")]
        AddEditVisitor = 28,
        [Description("View Residency Application")]
        ResidencyApplicationView = 29,

        [Description("Residency Application Initial Review")]
        ResidencyApplicationInitialReview = 30,

        [Description("Add Residency Application Reviewers")]
        ResidencyApplicationReviewTeamCreate = 31,


        [Description("Review Residency Application")]
        ResidencyApplicationReviewSubmit = 32,

        [Description("Approve/Reject Residency Application")]
        ResidencyApproveReject = 33,

        //[Description("Export Residency Application")]
        //ResidencyApplicationExport = 34,

        [Description("Set Calendar")]
        SetCalendarView = 35,


        [Description("View Expense Report")]
        ExpenseReportView = 37,

        [Description("Add/Edit Expenses")]
        ExpenseAdd = 38,

        [Description("Edit/Accept Expense Reports")]
        EditAcceptExpenseReports = 39,

        [Description("Institution CEO")]
        InstitutionCEO = 40,

        [Description("Institution Edit")]
        InstitutionEdit = 41,

        [Description("Institution Contact Add")]
        InstitutionContactAdd = 42,

        [Description("Program Edit")]
        ProgramEdit = 43,
        [Description("View Report")]
        ShowReport = 46,
        [Description("Add Report")]
        AddReport = 47,
        [Description("Delete Report")]
        DeleteReport = 49,
        [Description("View/Edit Self Study")]
        SelfStudyView = 50,
        [Description("Site Visit Details")]
        SiteVisitView = 51,
        [Description("Email Templates")]
        EmailTemplateView = 52,
        [Description("Standards")]
        StandardView = 53,
        [Description("Announements")]
        AnnounementsView = 54,
        [Description("Add/Edit Users")]
        ManageUserView = 55,
        [Description("Add/Edit roles and assign permissions")]
        AssignPermission = 56,
    }
}
