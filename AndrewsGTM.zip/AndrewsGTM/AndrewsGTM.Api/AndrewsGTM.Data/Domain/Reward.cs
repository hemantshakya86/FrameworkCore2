﻿using Framework.Repository;
using AndrewsGTM.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AndrewsGTM.Data.Domain
{
    public class Reward : Entity<int>
    {
        public Reward()
        {
           this.CreateDate=DateTime.Now;
        }
        public int EventID { get; set; }

        public int Priority { get; set; }

        public string Description { get; set; }

        public int PointsNeeded { get; set; }

        public DateTime CreateDate { get; set; }

        //public virtual ManageEvent ManageEvent { get; set; }
    }
    
}
