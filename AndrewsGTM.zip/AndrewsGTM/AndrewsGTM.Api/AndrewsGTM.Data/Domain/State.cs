﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AndrewsGTM.Data;
using Framework.Repository;

namespace AndrewsGTM.Data.Domain
{
    public class State : Entity<int>
    {
        /// <summary>
        /// To get  and set the State Code
        /// </summary>
        public string StateCode { get; set; }
        /// <summary>
        /// To get  and set the State Name
        /// </summary>
        public string StateName { get; set; }
        /// <summary>
        /// To get  and set the Contry ID
        /// </summary>
        public int CountryID { get; set; }
    }
}
