﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data;
using Framework.Repository;

namespace AndrewsGTM.Data.Domain
{
    public class Ticket : Entity<int>
    {
        public Ticket()
        {
            this.CreateDate = DateTime.Now;
        }
        public int EventID { get; set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public double Price { get; set; }

        public int Quantity { get; set; }

        public int QuantityInHand { get; set; }

        public int Points { get; set; }

        public DateTime CreateDate { get; set; }

        //public virtual  ManageEvent ManageEvent { get; set; }

        //private EntityCollection<TicketBarcode> ticketBarcodes;

        //public virtual EntityCollection<TicketBarcode> TicketBarcodes
        //{
        //    get { return this.ticketBarcodes ?? (this.ticketBarcodes = this.CreateCollection<TicketBarcode>()); }
        //}
    }
}
