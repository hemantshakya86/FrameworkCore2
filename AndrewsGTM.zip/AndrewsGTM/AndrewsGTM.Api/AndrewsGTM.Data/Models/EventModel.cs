﻿
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AndrewsGTM.Data.Models
{

    public class EventModel
    {
        public int ID { get; set; }
        [Required(ErrorMessage ="Required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Required")]
        public string City { get; set; }
        [Required(ErrorMessage = "Required")]
        public string ZipCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public DateTime? EventStartDate { get; set; }
        [Required(ErrorMessage = "Required")]
        public DateTime? EventEndDate { get; set; }

       // public FileUploadModel Logo { get; set; }
        public string LogoUrl { get; set; }


        public string DasboardImage { get; set; }
        public string DasboardImageUrl { get; set; }


        public string LandingPageImage { get; set; }
        public string LandingPageImageUrl { get; set; }


        [Required(ErrorMessage = "Required")]
        public string UniqueUrl { get; set; }

        public string EventManagerProfilePic { get; set; }
        public string EventManagerProfilePicUrl { get; set; }


        [Required(ErrorMessage = "Required")]
        public string EventManagerName { get; set; }

        [Required(ErrorMessage = "Email Is Required")]
        [EmailAddress(ErrorMessage = "Invalid email id")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email id")]
        public string EventManagerEmail { get; set; }

    }
}
