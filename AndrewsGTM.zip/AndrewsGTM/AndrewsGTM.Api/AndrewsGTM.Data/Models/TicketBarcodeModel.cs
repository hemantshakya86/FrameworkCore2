﻿using FrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FrameworkCore.Models
{

    public class TicketBarcodeModel
    {
        public int TicketID { get; set; }

        public string BarcodeImage { get; set; }


    }
}
