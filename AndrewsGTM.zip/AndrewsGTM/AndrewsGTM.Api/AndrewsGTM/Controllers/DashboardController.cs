﻿using System;

using AndrewsGTM.Data.Models;

using Microsoft.AspNetCore.Mvc;

namespace AndrewsGTM.Controllers
{
    [Route("api/[controller]")]
    public class DashboardController : Controller
    {
        
        //[HttpGet]
        //[HttpOptions]
        //[Route("sales")]
        //public SalesDataModel GetCapareSalesData()
        //{
        //    try
        //    {
        //        return dashboardService.GetCapareSalesData();
        //    }
        //    catch (ApiException)
        //    {
        //        throw;
        //    }
        //    catch (Exception exception)
        //    {
        //        throw new ApiException(exception.GetExceptionMessage());
        //    }
        //}
        //[HttpGet]
        //[HttpOptions]
        //[Route("threshold")]
        //public PagedListModel<InevntoryThresholdModel> GetThreshHoldData(string sortBy = "ThresHoldCount",
        //    string sortDirection = "asc", int page = 0, int size = 10)
        //{
        //    try
        //    {
        //        return dashboardService.GetThreshHoldData(sortBy,sortDirection,page,size);
        //    }
        //    catch (ApiException)
        //    {
        //        throw;
        //    }
        //    catch (Exception exception)
        //    {
        //        throw new ApiException(exception.GetExceptionMessage());
        //    }
        //}
    }
}
