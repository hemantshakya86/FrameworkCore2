﻿using System;

using AndrewsGTM.Data.Models;

using Microsoft.AspNetCore.Mvc;
using AndrewsGTM.Services;
using Framework.Core.Models;
using Framework.Core;
using Microsoft.AspNetCore.Authorization;
using FrameworkCore.Models;

namespace AndrewsGTM.Controllers
{
    [Authorize(Policy = "ApiUser")]
    [Route("api/[controller]/[action]")]
    public class EventManageController : Controller
    {
        private readonly IEventService eventService;
        public EventManageController(IEventService eventService)
        {
            this.eventService = eventService;
        }
        [HttpGet]
        public PagedListModel<EventModel> GetAllEvents(string name = null, string sortBy = "EventName", string sortDirection = "asc", int page = 0, int size = 500)
        {
            try
            {
                return eventService.GetAllEvents(name, sortBy, sortDirection, page, size);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpPost, DisableRequestSizeLimit]
        public void SaveEvent([FromBody] EventModel model)
        {
            try
            {
                int id = 0;
                eventService.SaveEvent(id, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpPut]
        public void SaveEvent(int id, EventModel model)
        {
            try
            {
                eventService.SaveEvent(id, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpGet]
        public EventModel EditEvent(int id)
        {
            try
            {
                return eventService.EditEvent(id);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpDelete("{eventID}")]
        [HttpOptions]
        public void DeleteEvent(int eventID)
        {
            try
            {
                eventService.DeleteEvent(eventID);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpOptions]
        [HttpPut("{eventid}")]
        public void UpdateEvent(int eventid, [FromBody] EventModel model)
        {
            try
            {
                eventService.UpdateEvent(eventid, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }



        [HttpPost]
        public FileUploadModel Upload()
        {
            try
            {
                var file = Request.Form.Files;
                return eventService.Upload(file);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpGet("{eventID}")]
        public PagedListModel<TicketModel> GetAllTickets(int eventID, string name = null, string sortBy = "Title", string sortDirection = "asc", int page = 0, int size = 500)
        {
            try
            {
                return eventService.GetAllTickets(eventID,name, sortBy, sortDirection, page, size);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpPost("{eventID}")]
        public void AddTicket([FromBody] TicketModel model, int eventID)
        {
            try
            {                
                eventService.AddTicket(eventID, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpOptions]
        [HttpPut("{id}")]
        //public void UpdateTicket(int id, int ticketID, EventModel model)
        public void UpdateTicket(int id, [FromBody] TicketModel model)
        {
            try
            {
                eventService.UpdateTicket(id, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpDelete("{ticketID}")]
        [HttpOptions]
        public void DeleteTicket(int ticketID)
        {
            try
            {
                eventService.DeleteTicket(ticketID);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpGet]
        [HttpOptions]
        [Route("getevent/{id:int}")]
        public TicketModel GetTicket(int id, int ticketID)
        {
            try
            {
                return eventService.GetTicket(id, ticketID);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpPost("{eventID}")]

        public void SaveReward([FromBody] RewardModel model, int eventID)
        {
            try
            {
                eventService.SaveReward(model, eventID);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpGet("{eventID}")]
        [HttpOptions]
        public PagedListModel<RewardModel> GetAllRewards(int eventID,string name = null, string sortBy = "Name", string sortDirection = "asc", int page = 0, int size = 500)
        {
            try
            {
                return eventService.GetAllRewards(eventID,name, sortBy, sortDirection, page, size);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpPut("{rewardID}")]
        [HttpOptions]
        public void UpdateReward(int rewardID, [FromBody] RewardModel model)
        {
            try
            {
                eventService.UpdateReward(rewardID, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }
        [HttpDelete("{rewardID}")]
        [HttpOptions]
        public void DeleteReward(int rewardID)
        {
            try
            {
                eventService.DeleteReward(rewardID);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }


    }
}
