﻿using System;

using AndrewsGTM.Data.Models;

using Microsoft.AspNetCore.Mvc;
using AndrewsGTM.Services;
using Framework.Core.Models;
using Framework.Core;
using Microsoft.AspNetCore.Authorization;

namespace AndrewsGTM.Controllers
{
 
    [Route("api/[controller]/[action]")]


    public class ManageAgentController : Controller
    {
        private readonly IAgentService agentService;
        public ManageAgentController(IAgentService agentService)
        {
            this.agentService = agentService;
        }

        [HttpGet]
        [HttpOptions]
        public PagedListModel<AgentModel> GetAllAgents(string name = null, string sortBy = "AgentName", string sortDirection = "asc", int page = 0, int size = 500)
        {
            try
            {
                return agentService.GetAllAgents(name, sortBy, sortDirection, page, size);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpPost]
        public void SaveAgent([FromBody] AgentModel model)
        {
            try
            {
                int id = 0;
                agentService.SaveAgent(id, model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpPut]
        public void UpdateAgent([FromBody] AgentModel model)
        {
            try
            {
                agentService.UpdateAgent(model);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        [HttpDelete("{agentID}")]
        [HttpOptions]
        public void DeleteAgent(int agentID)
        {
            try
            {
                agentService.DeleteAgent(agentID);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

    }
}