﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AndrewsGTM.Data;
using AndrewsGTM.Data.Models;
using Microsoft.AspNetCore.Mvc;
using AndrewsGTM.Services;
using AndrewsGTM.Data.Domain;
using Framework.Repository;
using Framework.Core.Models;
using Framework.Core;

namespace AndrewsGTM.Controllers
{

    [Route("api/[controller]/[action]")]
    public class ValuesController : Controller
    {
        private readonly IEventService eventService;
        public ValuesController(IEventService eventService)
        {
            this.eventService = eventService;
        }
        [HttpGet]
        [HttpOptions]
        public PagedListModel<EventModel> GetAllEvents(string name = null, string sortBy = "EventName", string sortDirection = "asc", int page = 0, int size = 500)
        {
            try
            {
                return eventService.GetAllEvents(name, sortBy, sortDirection, page, size);
            }
            catch (ApiException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new ApiException(exception.GetExceptionMessage());
            }
        }

        // GET api/values
        //[HttpGet]
        //public IEnumerable<ManageEvent> Get()
        //{
        //    IRepository<ManageEvent> eventRepository = unitOfWork.Get<ManageEvent>();
        //    IRepository<Country> coutryRepository = unitOfWork.Get<Country>();

        //    var countries = coutryRepository.Query.Where(s => s.ID == 1).Select(s=>s.States).ToList();

        //    //eventRepository.One(s => s.Name == "event");
        //    //ManageEvent manageEvent = new ManageEvent();
        //    //manageEvent.Name = "new event";
        //    //manageEvent.Address = "update event";
        //    //manageEvent.City = "new event";
        //    //manageEvent.DasboardImage = "new event";
        //    //manageEvent.EventEndDate = DateTime.Now;
        //    //manageEvent.EventStartDate = DateTime.Now;
        //    //manageEvent.EventManagerEmail = "new event";
        //    //manageEvent.EventManagerName = "new event";
        //    //manageEvent.LandingPageImage = "new event";
        //    //manageEvent.Logo = "new event";
        //    //eventRepository.Save(manageEvent);
        //    //unitOfWork.Commit();
        //    var eve = eventRepository.Query.ToList();

        //    return eve;
        //}

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
