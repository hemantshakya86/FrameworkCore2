﻿using Framework.Core.Models;
using AndrewsGTM.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AndrewsGTM.Services
{
    public interface IAgentService
    {
      //  FileUploadModel Upload();

        void SaveAgent(int? id, AgentModel model);
        PagedListModel<AgentModel> GetAllAgents(string name = null, string sortBy = "AgentName", string sortDirection = "asc", int page = 0, int size = 500);
        void UpdateAgent(AgentModel model);
        void DeleteAgent(int id);

    }
}
