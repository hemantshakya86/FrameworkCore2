﻿using Framework.Core.Models;
using Microsoft.AspNetCore.Http;
using AndrewsGTM.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AndrewsGTM.Services
{
    public interface IEventService
    {
        FileUploadModel Upload(IFormFileCollection formFileCollection);

        void SaveEvent(int? id, EventModel model);

        EventModel EditEvent(int id);
        void DeleteEvent(int id);

        void UpdateEvent(int id, EventModel model);

        PagedListModel<EventModel> GetAllEvents(string name = null, string sortBy = "EventName", string sortDirection = "asc", int page = 0, int size = 500);
        PagedListModel<TicketModel> GetAllTickets(int eventID,string name=null, string sortBy="Title", string sortDirection="asc", int page=0, int size=500);
        void AddTicket(int eventID, TicketModel model);
        void UpdateTicket(int id, TicketModel model);
        TicketModel GetTicket(int id, int ticketId);
        void DeleteTicket(int id);


        void SaveReward(RewardModel model, int eventID);
        PagedListModel<RewardModel> GetAllRewards(int eventID,string name = null, string sortBy = "Name", string sortDirection = "asc", int page = 0, int size = 5);
        void UpdateReward(int id, RewardModel model);
        void DeleteReward(int id);
    }
}
