﻿
using Framework.Repository;
using System.Threading.Tasks;


namespace AndrewsGTM.Services
{
    public interface IUnitOfWork 
    {
   
        
        int Commit();
        Task<int> CommitAsync();
        void Dispose();
        IRepository<TEntity> Get<TEntity>() where TEntity : class;
        void Rollback();
    }
}
