﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data.Models;
using System.Web;
using System.IO;

using AndrewsGTM.Data.Domain;

using AndrewsGTM.Services;

using Microsoft.AspNetCore.Http;

using Framework.Core.Models;
using Framework.Repository;
using Framework.Core;
using Framework.FileSystem;
using System.ComponentModel;

namespace PROMOSHARE.Services.Impl
{
    public class AgentService : IAgentService
    {
        private readonly IUnitOfWork unitOfWork;
        public AgentService(IUnitOfWork unitOfWork)
        {
           
            this.unitOfWork = unitOfWork;
        }
        public void SaveAgent(int? id, AgentModel model)
        {
            IRepository<ManageAgent> agentRepository = unitOfWork.Get<ManageAgent>();
            var mangeAgent = agentRepository.One(s => s.ID == id);
            if (model == null)
            {
                throw new ApiException("Model can not be null.");
            }
            if (string.IsNullOrWhiteSpace(model.FirstName))
            {
                throw new ApiException("Please enter First Name.");
            }
            if (string.IsNullOrWhiteSpace(model.LastName))
            {
                throw new ApiException("Please enter Last Name.");
            }
            if (string.IsNullOrWhiteSpace(model.City))
            {
                throw new ApiException("Please enter city.");
            }
            if (string.IsNullOrWhiteSpace(model.State))
            {
                throw new ApiException("Please enter state.");
            }

            
            try
            {
                if (mangeAgent == null)
                {
                    mangeAgent = new ManageAgent();

                    mangeAgent.FirstName = model.FirstName;
                    mangeAgent.LastName = model.LastName;
                    mangeAgent.City = model.City;
                    mangeAgent.State = model.State;
                    mangeAgent.Email = model.Email;

                    mangeAgent.OldPassword = model.Password;
                    mangeAgent.NewPassword = model.RepeatPassword;
                    mangeAgent.Phone = model.Phone;
                    agentRepository.Save(mangeAgent);
                    unitOfWork.Commit();
                }

            }
            catch (Exception ex)
            {

                throw new ApiException(ex.GetExceptionMessage());
            }
        }



        public PagedListModel<AgentModel> GetAllAgents(string name = null, string sortBy = "AgentName", string sortDirection = "asc", int page = 0, int size = 500)
        {

            return null;
            //IRepository<ManageAgent> agentRepository = unitOfWork.Get<ManageAgent>();
            //IQueryable<ManageAgent> queryable = agentRepository.Query;
            //var agents = queryable.OrderBy(s => new { s.FirstName, s.City, s.State }).Select(s => new
            //{
            //    ID = s.ID,
            //    FirstName = s.FirstName,
            //    LastName = s.LastName,
            //    City = s.City,
            //    State = s.State,
            //    Email = s.Email,
            //    Phone = s.Phone,
            //    OldPassword = s.OldPassword,
            //    NewPassword = s.NewPassword,
                

            //}).ToList().Select(s => new AgentModel()
            //{
            //    ID = s.ID,
            //    FirstName = s.FirstName,
            //    LastName = s.LastName,
            //    City = s.City,
            //    State = s.State,
            //    Email = s.Email,
            //    Phone = s.Phone,
            //    Password = s.OldPassword,
            //    RepeatPassword = s.NewPassword,
               
            //}).ToPagedList(page, size);
            //return new PagedListModel<AgentModel>(agents, agents.PageIndex, agents.PageSize, agents.TotalCount);
        }

        public void UpdateAgent(AgentModel model)
        {
            IRepository<ManageAgent> agentRepository = unitOfWork.Get<ManageAgent>();
            var mangeAgent = agentRepository.One(s => s.ID == model.ID);
            if (mangeAgent != null)
            {
                mangeAgent.FirstName = model.FirstName;
                mangeAgent.LastName = model.LastName;
                mangeAgent.City = model.City;
                mangeAgent.State = model.State;
                mangeAgent.Email = model.Email;

                mangeAgent.OldPassword = model.Password;
                mangeAgent.NewPassword = model.RepeatPassword;
                mangeAgent.Phone = model.Phone;
                agentRepository.Save(mangeAgent);
                unitOfWork.Commit();
            }
        }

       
        public void DeleteAgent(int id)
        {
            IRepository<ManageAgent> repository = unitOfWork.Get<ManageAgent>();

            var agent = repository.One(x => x.ID == id);

            repository.Remove(agent);
            unitOfWork.Commit();
        }
    }
}
