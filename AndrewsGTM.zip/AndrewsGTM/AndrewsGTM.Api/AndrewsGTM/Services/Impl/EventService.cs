﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AndrewsGTM.Data.Models;
using System.Web;
using System.IO;

using AndrewsGTM.Data.Domain;

using AndrewsGTM.Services;

using Microsoft.AspNetCore.Http;

using Framework.Core.Models;
using Framework.Repository;
using Framework.Core;
using Framework.FileSystem;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc;

namespace PROMOSHARE.Services.Impl
{
    public class EventService : IEventService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IVirtualFileSystem fileSystem;
        public EventService(IUnitOfWork unitOfWork, IVirtualFileSystem fileSystem)
        {

            this.unitOfWork = unitOfWork;
            this.fileSystem = fileSystem;
        }

        public FileUploadModel Upload(IFormFileCollection files)
        {
            FileUploadModel model = new FileUploadModel();
            string fullFileName = "";
            if (files.Count > 0)
            {
                var postedFileBase = files.FirstOrDefault();
                if (postedFileBase.ContentType.Length > 0)
                {
                    var originalFileName = postedFileBase.FileName;
                    var fileExtension = Path.GetExtension(originalFileName);
                    var fileName = Path.GetFileNameWithoutExtension(postedFileBase.FileName);
                    fullFileName = fileName + fileExtension;
                    if (
                        fileExtension == ".jpg" || fileExtension == ".JPG"
                        || fileExtension == ".gif" || fileExtension == ".GIF"
                        || fileExtension == ".jpeg" || fileExtension == ".JPEG"
                        || fileExtension == ".png" || fileExtension == ".PNG"

                        )
                    {
                        MemoryStream ms = new MemoryStream();
                        postedFileBase.CopyTo(ms);
                        ms.Seek(0, SeekOrigin.Begin);
                        try
                        {
                            fileName = fileName + " " + DateTime.Now.ToString("yyyy-MM-dd");
                            fullFileName = fileName + fileExtension;
                            int counter = 0;
                            while (fileSystem.RootFolder.FileExists(fullFileName))
                            {
                                fullFileName = fileName + " (" + ++counter + ") " + fileExtension;
                            }
                            fileSystem.CreateFile(fullFileName, ms);
                            model.FileName = fullFileName;
                            model.FileType = fileSystem.RootFolder.FileExists(fullFileName)
                               ? fileSystem.RootFolder.GetFile(fullFileName).WebUrl
                               : "";
                            return model;
                        }
                        catch (Exception exception)
                        {
                            throw new ApiException(exception.Message);
                        }
                    }
                }
            }
            return model;
        }
        public void SaveEvent(int? id, EventModel model)
        {
            IRepository<ManageEvent> eventRepository = unitOfWork.Get<ManageEvent>();
            // IVirtualFileSystem fileSystem = Container.Get<IVirtualFileSystem>();
            var manageEvent = eventRepository.One(s => s.ID == id);
            if (model == null)
            {
                throw new ApiException("Model can not be null.");
            }

            if (model.Name == null)
            {
                throw new ApiException("Name can not be null.");
            }
            //if (string.IsNullOrWhiteSpace(model.Logo))
            //{
            //    throw new ApiException("Please upload logo.");
            //}
            //if (string.IsNullOrWhiteSpace(model.DasboardImage))
            //{
            //    throw new ApiException("Please upload dasboard image.");
            //}
            //if (string.IsNullOrWhiteSpace(model.LandingPageImage))
            //{
            //    throw new ApiException("Please upload landing page image.");
            //}
            //if (string.IsNullOrWhiteSpace(model.EventManagerProfilePic))
            //{
            //    throw new ApiException("Please upload profile picture.");
            //}
            try
            {
                if (manageEvent == null)
                {
                    manageEvent = new ManageEvent();
                    eventRepository.Save(manageEvent);
                }
                manageEvent.Name = model.Name;
                manageEvent.UniqueUrl = model.UniqueUrl;
                manageEvent.Address = model.Address;
                manageEvent.City = model.City;
                manageEvent.ZipCode = model.ZipCode;

                manageEvent.EventEndDate = model.EventEndDate;
                manageEvent.EventStartDate = model.EventStartDate;
                manageEvent.EventManagerEmail = model.EventManagerEmail;
                manageEvent.EventManagerName = model.EventManagerName;
                //manageEvent.Logo = model.Logo;
                manageEvent.DasboardImage = model.DasboardImage;
                manageEvent.LandingPageImage = model.LandingPageImage;
                manageEvent.EventManagerProfilePic = model.EventManagerProfilePic;

                unitOfWork.Commit();
                //Stream stream = new MemoryStream(model.Logo.Value);
               // fileSystem.CreateTempFile(model.Logo.FileName, stream);
                //if (fileSystem.FolderExists(Convert.ToString(manageEvent.ID)))
                //{
                //    int counter = 0;

                //    fileSystem = Container.Get<IVirtualFileSystem>().With(Convert.ToString(manageEvent.ID));
                //    IVirtualFile intentFile = fileSystem.TempFolder.GetFile(model.Logo);
                //    fileSystem.MoveFile(intentFile, fileSystem.RootFolder);
                //    IVirtualFile deleteFile = intentFile;
                //    fileSystem.DeleteFile(deleteFile);

                //    IVirtualFile intentFileLanding = fileSystem.TempFolder.GetFile(model.LandingPageImage);
                //    fileSystem.MoveFile(intentFileLanding, fileSystem.RootFolder);
                //    IVirtualFile deleteFileLanding = intentFileLanding;
                //    fileSystem.DeleteFile(deleteFileLanding);

                //    IVirtualFile intentFileDasboard = fileSystem.TempFolder.GetFile(model.DasboardImage);
                //    fileSystem.MoveFile(intentFileDasboard, fileSystem.RootFolder);
                //    IVirtualFile deleteFileDasboard = intentFileDasboard;
                //    fileSystem.DeleteFile(deleteFileDasboard);

                //    IVirtualFile intentFileProfile = fileSystem.TempFolder.GetFile(model.EventManagerProfilePic);
                //    fileSystem.MoveFile(intentFileProfile, fileSystem.RootFolder);
                //    IVirtualFile deleteFileProfile = intentFileProfile;
                //    fileSystem.DeleteFile(deleteFileProfile);
                //    unitOfWork.Commit();

                //}
                //else
                //{
                //    var virtualFolder = fileSystem.CreateFolder(Convert.ToString(manageEvent.ID));
                //    fileSystem = Container.Get<IVirtualFileSystem>().With(Convert.ToString(manageEvent.ID));
                //    IVirtualFile intentFile = fileSystem.TempFolder.GetFile(model.Logo);
                //    fileSystem.MoveFile(intentFile, fileSystem.RootFolder);
                //    IVirtualFile deleteFile = intentFile;
                //    fileSystem.DeleteFile(deleteFile);

                //    IVirtualFile intentFileLanding = fileSystem.TempFolder.GetFile(model.LandingPageImage);
                //    fileSystem.MoveFile(intentFileLanding, fileSystem.RootFolder);
                //    IVirtualFile deleteFileLanding = intentFileLanding;
                //    fileSystem.DeleteFile(deleteFileLanding);

                //    IVirtualFile intentFileDasboard = fileSystem.TempFolder.GetFile(model.DasboardImage);
                //    fileSystem.MoveFile(intentFileDasboard, fileSystem.RootFolder);
                //    IVirtualFile deleteFileDasboard = intentFileDasboard;
                //    fileSystem.DeleteFile(deleteFileDasboard);

                //    IVirtualFile intentFileProfile = fileSystem.TempFolder.GetFile(model.EventManagerProfilePic);
                //    fileSystem.MoveFile(intentFileProfile, fileSystem.RootFolder);
                //    IVirtualFile deleteFileProfile = intentFileProfile;
                //    fileSystem.DeleteFile(deleteFileProfile);
                //    unitOfWork.Commit();
                //}

            }
            catch (Exception ex)
            {

                throw new ApiException(ex.GetExceptionMessage());
            }
        }

        public void UpdateEvent(int id, EventModel model)
        {
            IRepository<ManageEvent> manageeventRepository = unitOfWork.Get<ManageEvent>();
            var manageevent = manageeventRepository.One(x => x.ID == id);
            if (manageevent != null)
            {

                manageevent.Name = model.Name;
                manageevent.UniqueUrl = model.UniqueUrl;
                manageevent.Address = model.Address;
                manageevent.City = model.City;
                manageevent.ZipCode = model.ZipCode;
                manageevent.EventEndDate = model.EventEndDate;
                manageevent.EventStartDate = model.EventStartDate;
                manageevent.EventManagerEmail = model.EventManagerEmail;
                manageevent.EventManagerName = model.EventManagerName;
                manageevent.DasboardImage = model.DasboardImage;
                manageevent.LandingPageImage = model.LandingPageImage;
                manageevent.EventManagerProfilePic = model.EventManagerProfilePic;
                manageeventRepository.Save(manageevent);
                unitOfWork.Commit();

            }
        }

        public void DeleteEvent(int id)
        {
            IRepository<ManageEvent> repository = unitOfWork.Get<ManageEvent>();

            var manageevent = repository.One(x => x.ID == id);

            repository.Remove(manageevent);
            unitOfWork.Commit();
        }

        
        public PagedListModel<EventModel> GetAllEvents(string name = null, string sortBy = "EventName", string sortDirection = "asc", int page = 0, int size = 500)
        {
            IRepository<ManageEvent> eventRepository = unitOfWork.Get<ManageEvent>();
            IQueryable<ManageEvent> queryable = eventRepository.Query;
            var events = queryable.OrderBy(s => new { s.Name, s.City, s.ZipCode }).Select(s => new
            {
                ID = s.ID,
                Name = s.Name,
                UniqueUrl = s.UniqueUrl,
                Address = s.Address,
                City = s.City,
                ZipCode = s.ZipCode,
                EventEndDate = s.EventEndDate,
                EventStartDate = s.EventStartDate,
                EventManagerEmail = s.EventManagerEmail,
                EventManagerName = s.EventManagerName,
                Logo = s.Logo,
                DasboardImage = s.DasboardImage,
                LandingPageImage = s.LandingPageImage,
                EventManagerProfilePic = s.EventManagerProfilePic,
                DasboardImageUrl = GetFile(s.ID, s.DasboardImage),
                LogoUrl = GetFile(s.ID, s.Logo),
                LandingPageImageUrl = GetFile(s.ID, s.LandingPageImage),
                EventManagerProfileUrl = GetFile(s.ID, s.EventManagerProfilePic),

            }).ToList().Select(s => new EventModel()
            {
                ID = s.ID,
                Name = s.Name,
                UniqueUrl = s.UniqueUrl,
                Address = s.Address,
                City = s.City,
                ZipCode = s.ZipCode,
                EventEndDate = s.EventEndDate,
                EventStartDate = s.EventStartDate,
                EventManagerEmail = s.EventManagerEmail,
                EventManagerName = s.EventManagerName,
               // Logo = s.Logo,
                DasboardImage = s.DasboardImage,
                LandingPageImage = s.LandingPageImage,
                EventManagerProfilePic = s.EventManagerProfilePic,
                DasboardImageUrl = GetFile(s.ID, s.DasboardImage),
                LogoUrl = GetFile(s.ID, s.Logo),
                LandingPageImageUrl = GetFile(s.ID, s.LandingPageImage),
                EventManagerProfilePicUrl = GetFile(s.ID, s.EventManagerProfilePic),
            }).ToPagedList(page, size);
            return new PagedListModel<EventModel>(events, events.PageIndex, events.PageSize, events.TotalCount);
        }

        public EventModel EditEvent(int id)
        {
            EventModel model = new EventModel();
            IRepository<ManageEvent> eventRepository = unitOfWork.Get<ManageEvent>();
            var manageEvent = eventRepository.One(s => s.ID == id);
            if (manageEvent != null)
            {
                model.Name = manageEvent.Name;
                model.Address = manageEvent.Address;
                model.City = manageEvent.City;
                model.ZipCode = manageEvent.ZipCode;
                model.UniqueUrl = manageEvent.UniqueUrl;
                if (manageEvent.EventEndDate != null) model.EventEndDate = manageEvent.EventEndDate.Value.Date;
                if (manageEvent.EventStartDate != null) model.EventStartDate = manageEvent.EventStartDate.Value.Date;
                model.EventManagerEmail = manageEvent.EventManagerEmail;
                model.EventManagerName = manageEvent.EventManagerName;
                //model.Logo = manageEvent.Logo;
                model.DasboardImage = manageEvent.DasboardImage;
                model.LandingPageImage = manageEvent.LandingPageImage;
                model.EventManagerProfilePic = manageEvent.EventManagerProfilePic;
                model.DasboardImageUrl = GetFile(manageEvent.ID, manageEvent.DasboardImage);
                model.LogoUrl = GetFile(manageEvent.ID, manageEvent.Logo);
                model.LandingPageImageUrl = GetFile(manageEvent.ID, manageEvent.LandingPageImage);
                model.EventManagerProfilePicUrl = GetFile(manageEvent.ID, manageEvent.EventManagerProfilePic);
            }
            return model;
        }

        private  string GetFile(int id, string fileName)
        {
            
            var virtualFileSystem = fileSystem.With(id.ToString());

            var file = virtualFileSystem.FileExists(fileName)
                ? virtualFileSystem.GetFile(fileName).WebUrl
                : "";

            return file;
            return "0";
        }

        public PagedListModel<TicketModel> GetAllTickets(int eventID,string name = null, string sortBy = "Title", string sortDirection = "asc", int page = 0, int size = 500)            
        {
            IRepository<Ticket> ticketRepository = unitOfWork.Get<Ticket>();
            IQueryable<Ticket> ticketQueryable = ticketRepository.Query.Where(x=>x.EventID==eventID);
            var tickets = ticketQueryable.OrderBy(x => new { x.Title }).Select(x => new
            {
                ID = x.ID,
                EventID=x.EventID,
                Title=x.Title,
                Description = x.Description,
                Price=x.Price,
                Quantity=x.Quantity,
                Points=x.Points,
                QuantityInHand=x.QuantityInHand
            }).ToList().Select(x => new TicketModel()
            {
                ID = x.ID,
                EventID = x.EventID,
                Title=x.Title,
                Description = x.Description,
                Price = x.Price,
                Quantity = x.Quantity,
                Points = x.Points,
                QuantityInHand=x.QuantityInHand
            }).ToPagedList(page, size);
            return new PagedListModel<TicketModel>(tickets, tickets.PageIndex, tickets.PageSize,tickets.TotalCount);
        }

        public void AddTicket(int eventID, TicketModel model)
        {
            IRepository<Ticket> ticketRepository = unitOfWork.Get<Ticket>();
            try
            {
                var tickets = new Ticket();
                tickets.EventID = eventID;
                tickets.Title = model.Title;
                tickets.Description = model.Description;
                tickets.Price = model.Price;
                tickets.Quantity = model.Quantity;
                tickets.Points = model.Points;
                tickets.QuantityInHand = model.QuantityInHand;
                ticketRepository.Save(tickets);
                unitOfWork.Commit();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.GetExceptionMessage());
            }

        }

        public void UpdateTicket(int id, TicketModel model)
        {
            IRepository<Ticket> ticketRepository = unitOfWork.Get<Ticket>();
            var ticket = ticketRepository.One(x => x.ID == id);
            if(ticket!=null)
            {
                                
                ticket.Title = model.Title;
                ticket.Description = model.Description;
                ticket.Price = model.Price;
                ticket.Quantity = model.Quantity;
                ticket.Points = model.Points;
                ticket.QuantityInHand = model.QuantityInHand;
                ticketRepository.Save(ticket);
                unitOfWork.Commit();

            }
        }

        public TicketModel GetTicket(int id, int ticketId)
        {
            throw new NotImplementedException();
        }

        public void DeleteTicket(int id)
        {
            IRepository<Ticket> repository = unitOfWork.Get<Ticket>();

            var ticket = repository.One(x => x.ID == id);

            repository.Remove(ticket);
            unitOfWork.Commit();
        }


        public void SaveReward(RewardModel model, int eventID)
        {
            IRepository<Reward> repository = unitOfWork.Get<Reward>();


            var reward = new Reward();
            reward.EventID = eventID;
            reward.Priority = model.Priority;
            reward.PointsNeeded = model.PointNeeded;
            reward.Description = model.Description;
            repository.Save(reward);
            unitOfWork.Commit();

        }

        public PagedListModel<RewardModel> GetAllRewards(int eventID,string name = null, string sortBy = "Name", string sortDirection = "asc", int page = 0, int size = 500)
        {
            IRepository<Reward> repository = unitOfWork.Get<Reward>();
            IQueryable<Reward> queryable = repository.Query.Where(x=>x.EventID== eventID);
            var events = queryable.OrderBy(s => new { s.Description }).Select(s => new
            {
                ID = s.ID,
                Description = s.Description,
                Priority = s.Priority,
                PointsNeeded = s.PointsNeeded,


            }).ToList().Select(s => new RewardModel()
            {
                Id = s.ID,
                Description = s.Description,
                PointNeeded = s.PointsNeeded,
                Priority = s.Priority,

            }).ToPagedList(page, size);
            return new PagedListModel<RewardModel>(events, events.PageIndex, events.PageSize, events.TotalCount);
        }

        public void UpdateReward(int id, RewardModel model)
        {
            
            IRepository<Reward> repository = unitOfWork.Get<Reward>();

            var reward = repository.One(x => x.ID == id);
            if (reward!=null)
            {

                //reward.ID = model.ID;
                reward.Description = model.Description;
                reward.Priority = model.Priority;
                reward.PointsNeeded = model.PointNeeded;
                repository.Save(reward);
                unitOfWork.Commit();

            }
           
        }

        public void DeleteReward(int id)
        {
            IRepository<Reward> repository = unitOfWork.Get<Reward>();

            var reward = repository.One(x => x.ID == id);

            repository.Remove(reward);
            unitOfWork.Commit();
        }
    }
}
