// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    client: {
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    files: [{
      pattern: './src/test.ts',
      watched: false
    }],
    preprocessors: {
      
    },
    mime: {
      'text/x-typescript': ['ts', 'tsx']
    },
    coverageIstanbulReporter: {
      dir: require('path').join(__dirname, 'coverage'), reports: ['html', 'lcovonly', 'text-summary', 'json'],
      dir: 'coverage/', // if using webpack and pre-loaders, work around webpack breaking the source path
      fixWebpackSourcePaths: true,
      skipFilesWithNoCoverage: true,
      // enforce percentage thresholds
      thresholds: {
        global: { // thresholds for all files
          statements: 85,
          lines: 85,
          branches: 79,
          functions: 85
        },
        each: { // thresholds per file
          statements: 80,
          lines: 80,
          branches: 70,
          functions: 80,
          overrides: {

          }
        }
      }
    },
    
    reporters: ['progress', 'coverage-istanbul', 'kjhtml'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: false,
    browsers: ['ChromeHeadless'],
    browserNoActivityTimeout: 20000,
    singleRun: false
  });
};
