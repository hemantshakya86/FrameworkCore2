import { Injectable } from '@angular/core';
import { environment } from './../environments/environment';
import * as lodash from 'lodash';

@Injectable()
export class Constants {
  static readonly GTMMaxWidth = '1366px'; // used for angular animations

  readonly IsProduction: boolean = environment.production;

  readonly UserDataKey = 'GTMData';

  get ApiConfig(): any {
    const ApiConfig = lodash.merge({
      HOST: '',
      PORT: '',
      PATH: '',
      API_PREFIX: 'api',
      baseUrl: null,
      apiUrl: null
    }, environment.apiConfig || {});

    function buildBaseUrl(config) {
      let url;
      if (config.PORT && config.PORT !== '') {
        url = `${config.HOST}:${config.PORT}/${config.PATH}`;
      } else {
        url = `${config.HOST}/${config.PATH}`;
      }
      if (lodash.endsWith(url, '/')) {
        url = url.slice(0, -1);
      }

      return url;
    }

    ApiConfig.baseUrl = buildBaseUrl(ApiConfig);

    ApiConfig.apiUrl = ApiConfig.API_PREFIX !== ''
      ? `${ApiConfig.baseUrl}/${ApiConfig.API_PREFIX}`
      : ApiConfig.baseUrl;

    return ApiConfig;
  }
}
