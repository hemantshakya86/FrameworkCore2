import { Routes } from '@angular/router';

import { MainComponent, HomeComponent, MainResolver } from './core';
import { LoginComponent, NotAuthenticatedComponent } from './auth';
import { DefaultPageComponent } from './default-page';


export const appRoutes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  {
    // path: '', component: MainComponent, resolve: { authentication: MainResolver },
    path: '', component: MainComponent,
    children: [
      { path: 'home', component: HomeComponent, data: { title: '' } },
      { path: 'default', component: DefaultPageComponent, data: { title: 'Pickups' } },
      { path: 'login', component: LoginComponent, data: { title: 'Login' } },
      { path: 'notAuthenticated', component: NotAuthenticatedComponent, data: { title: 'Not Authenticated' } }
    ]
  },
  { path: '**', redirectTo: '/home' }
];
