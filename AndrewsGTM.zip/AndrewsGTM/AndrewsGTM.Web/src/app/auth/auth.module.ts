import { NgModule } from '@angular/core';

import { LoginComponent } from './login-view';
import { NotAuthenticatedComponent } from './not-authenticated-view';
import { CommonModule } from '../common';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    LoginComponent,
    NotAuthenticatedComponent
  ],
  exports: [
    LoginComponent,
    NotAuthenticatedComponent
  ],
  providers: []
})
export class AuthModule {
}
