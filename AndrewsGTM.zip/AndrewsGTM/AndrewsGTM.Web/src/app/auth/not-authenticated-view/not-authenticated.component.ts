import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gtm-not-authenticated',
  templateUrl: './not-authenticated.component.html',
  styleUrls: ['./not-authenticated.component.scss']
})
export class NotAuthenticatedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
