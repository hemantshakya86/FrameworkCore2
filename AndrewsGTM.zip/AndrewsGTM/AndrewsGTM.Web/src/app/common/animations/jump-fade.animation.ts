import { trigger, animate, transition, style, query, group } from '@angular/animations';
import { Constants } from '../..';

export const jumpFadeAnimation =
  trigger('jumpFadeAnimation', [
    transition('* <=> *', [
      query(':enter, :leave',
        style(
          { display: 'block', position: 'fixed', width: 'inherit', maxWidth: Constants.GTMMaxWidth })
        , { optional: true }),
      group([
        query(':enter', [
          style({ opacity: 0, transform: 'translateY(-200px)' }),
          animate('0.5s 0.9s ease-in-out', style({ opacity: 1, transform: 'translateY(0)' }))
        ], { optional: true }),
        query(':leave', [
          style({ opacity: 1, transform: 'translateY(0)' }),
          animate('0.3s ease-in-out', style({ opacity: 0, transform: 'translateY(200px)' }))
        ], { optional: true })
      ])
    ])
  ]);
