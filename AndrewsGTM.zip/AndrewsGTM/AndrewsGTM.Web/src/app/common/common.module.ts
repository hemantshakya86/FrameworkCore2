import { NgModule } from '@angular/core';
import { CommonModule as AngularCommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import {
  AccordionModule, BsDropdownModule, CollapseModule, DatepickerModule, ModalModule, PaginationModule, PopoverModule,
  TabsModule, TypeaheadModule
} from 'ngx-bootstrap';

import { Components } from './components';

@NgModule({
  imports: [
    AngularCommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,

    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    PaginationModule.forRoot(),
    DatepickerModule.forRoot(),
    ModalModule.forRoot(),
    PopoverModule.forRoot(),
    AccordionModule.forRoot(),
    CollapseModule.forRoot(),
    TypeaheadModule.forRoot(),

  ],
  declarations: [
    ...Components
  ],
  exports: [
    ...Components,
    AngularCommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,

    BsDropdownModule,
    TabsModule,
    PaginationModule,
    DatepickerModule,
    ModalModule,
    PopoverModule,
    AccordionModule,
    CollapseModule,
    TypeaheadModule,

  ],
  providers: [DatePipe]
})
export class CommonModule {
}
