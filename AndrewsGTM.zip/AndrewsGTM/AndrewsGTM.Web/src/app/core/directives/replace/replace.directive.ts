import { Directive, ElementRef, OnInit } from '@angular/core';

@Directive({
  // tslint:disable-next-line:max-line-length
  selector: '[gtmHostReplace], gtm-aside, gtm-breadcrumbs, gtm-footer, gtm-header, gtm-sidebar, gtm-sidebar-footer, gtm-sidebar-form, gtm-sidebar-header, gtm-sidebar-minimizer, gtm-sidebar-nav, gtm-sidebar-nav-dropdown, gtm-sidebar-nav-item, gtm-sidebar-nav-link, gtm-sidebar-nav-title'
})
export class ReplaceDirective implements OnInit {

  constructor(private el: ElementRef) { }

  // wait for the component to render completely
  ngOnInit() {
    const nativeElement: HTMLElement = this.el.nativeElement;
    const parentElement: HTMLElement = nativeElement.parentElement;
    // move all children out of the element
    while (nativeElement.firstChild) {
      parentElement.insertBefore(nativeElement.firstChild, nativeElement);
    }
    // remove the empty element(the host)
    parentElement.removeChild(nativeElement);
  }
}
