import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gtm-footer',
  templateUrl: './gtm-footer.component.html',
  styleUrls: ['./gtm-footer.component.scss']
})
export class GtmFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
