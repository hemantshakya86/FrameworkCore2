export * from './gtm-footer.component';
