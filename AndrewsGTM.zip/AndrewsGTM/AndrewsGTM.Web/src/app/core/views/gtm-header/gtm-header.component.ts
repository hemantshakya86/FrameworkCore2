import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gtm-header',
  templateUrl: './gtm-header.component.html',
  styleUrls: ['./gtm-header.component.scss']
})
export class GtmHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
