import { Component } from '@angular/core';

@Component({
  selector: 'gtm-sidebar-minimizer',
  templateUrl: './gtm-sidebar-minimizer.component.html'
})
export class GtmSidebarMinimizerComponent { }
