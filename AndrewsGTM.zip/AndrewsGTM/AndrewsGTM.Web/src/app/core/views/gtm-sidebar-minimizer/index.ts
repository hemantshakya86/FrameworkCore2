export * from './gtm-sidebar-minimizer.component';
