import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gtm-sidebar',
  templateUrl: './gtm-sidebar.component.html',
  styleUrls: ['./gtm-sidebar.component.scss']
})
export class GtmSidebarComponent implements OnInit {
  isActive = false;
  showMenu = '';
  constructor() { }

  ngOnInit() {
  }

  eventCalled() {
      this.isActive = !this.isActive;
  }
  addExpandClass(element: any) {
      if (element === this.showMenu) {
          this.showMenu = '0';
      } else {
          this.showMenu = element;
      }
  }
}
