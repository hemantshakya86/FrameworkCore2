import { MainComponent } from './main';
import { HomeComponent } from './home';
import { GtmHeaderComponent } from './gtm-header';
import { GtmFooterComponent, GtmSidebarComponent, GtmBreadcrumbsComponent, GtmSidebarMinimizerComponent } from '.';
import { APP_SIDEBAR_NAV } from './gtm-sidebar-nav';

export * from './main';
export * from './home';
export * from './gtm-header';
export * from './gtm-footer/index';
export * from './gtm-sidebar';
export * from './gtm-breadcrumbs';
export * from './gtm-sidebar-minimizer';

export const Views = [
  MainComponent,
  HomeComponent,
  GtmHeaderComponent,
  GtmFooterComponent,
  GtmSidebarComponent,
  GtmBreadcrumbsComponent,
  GtmSidebarMinimizerComponent,
  APP_SIDEBAR_NAV
];
