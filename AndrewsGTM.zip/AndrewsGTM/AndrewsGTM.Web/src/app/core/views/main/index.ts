export * from './main.component';
export * from './main.resolver';
