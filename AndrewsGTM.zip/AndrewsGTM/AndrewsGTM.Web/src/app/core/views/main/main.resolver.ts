import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class MainResolver {

  constructor() {
  }
}
