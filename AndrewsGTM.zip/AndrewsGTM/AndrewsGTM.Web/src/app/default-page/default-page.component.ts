import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gtm-default-page',
  templateUrl: './default-page.component.html',
  styleUrls: ['./default-page.component.scss']
})
export class DefaultPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
