import { NgModule } from '@angular/core';

import { CommonModule } from '../common';
import { DefaultPageComponent } from './default-page.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    DefaultPageComponent
  ],
  exports: [
  ],
  providers: []
})
export class DefaultModule {
}
