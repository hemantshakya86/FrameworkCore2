export * from './default-page.component';
