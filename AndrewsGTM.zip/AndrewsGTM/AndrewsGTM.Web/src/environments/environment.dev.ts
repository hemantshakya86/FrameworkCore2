export const environment = {
  production: false,
  apiConfig: {
    HOST: '',  // TODO API
    PORT: '',
    PATH: '',
    API_PREFIX: ''
  }
};
