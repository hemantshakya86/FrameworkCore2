export const environment = {
  production: true,
  apiConfig: {
    HOST: 'api', // TODO api path
    PORT: '',
    PATH: '',
    API_PREFIX: ''
  }
};
