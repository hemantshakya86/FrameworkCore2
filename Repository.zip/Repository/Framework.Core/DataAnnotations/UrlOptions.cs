namespace DataAnnotationsExtensions
{
    public enum UrlOptions
    {
        RequireProtocol,
        OptionalProtocol,
        DisallowProtocol
    }
}