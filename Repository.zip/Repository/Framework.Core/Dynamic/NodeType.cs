﻿namespace Framework.Dynamic
{
    internal enum NodeType
    {
        Element,
        Attribute
    }
}