﻿using Framework.Repository;
using System;

namespace Framework.Repository
{
    public abstract class AggregateEntity : AggregateEntity<Guid>
    {
    }
}
