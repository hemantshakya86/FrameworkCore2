﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace Framework.Repository
{
    ///-------------------------------------------------------------------------------------------------
    /// <summary>
    ///     Base entity.
    /// </summary>
    ///-------------------------------------------------------------------------------------------------
    public abstract class BaseEntity : IBaseEntity
    {
        [Timestamp]
        public byte[] RowVersion { get; protected internal set; }

        protected EntityCollection<T> CreateCollection<T>() where T : class, IBaseEntity, new()
        {
            return new EntityCollection<T>();
        }
    }
}
