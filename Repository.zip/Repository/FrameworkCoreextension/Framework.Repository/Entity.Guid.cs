﻿using System;

namespace Framework.Repository
{
    /// <summary>
    /// REprsent a Entity with Guid as Primary Key.
    /// </summary>
    public abstract class Entity : Entity<Guid>
    {
    }
}
