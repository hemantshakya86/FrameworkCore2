﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace  Framework.Repository

{
    ///-------------------------------------------------------------------------------------------------
    /// <summary>
    ///     Entity.
    /// </summary>
    ///-------------------------------------------------------------------------------------------------
    [DebuggerDisplay("{DebuggerDisplay,nq}")]
    public abstract class Entity<T> : BaseEntity, IEntity<T>
    {
        protected Entity()
        {
            Type type = typeof(T);

            if (type != typeof(string) && type != typeof(Guid) && type != typeof(int) && type != typeof(long))
            {
                throw new InvalidConstraintException("Only String, Integer & Long is supported as Entity ID");
            }
        }

        ///-------------------------------------------------------------------------------------------------
        /// <summary>
        ///     Gets or sets the identifier.
        /// </summary>
        ///
        /// <value>
        ///     The identifier.
        /// </value>
        ///-------------------------------------------------------------------------------------------------
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public T ID { get; set; }

       
     
    }
}
