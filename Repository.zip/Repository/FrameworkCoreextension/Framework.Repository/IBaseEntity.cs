﻿using System.ComponentModel;

namespace Framework.Repository
{
    ///-------------------------------------------------------------------------------------------------
    /// <summary>
    ///     Interface for base entity.
    /// </summary>
    ///-------------------------------------------------------------------------------------------------
    public interface IBaseEntity
    {
       
        byte[] RowVersion { get; }

      
    }
}
