﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Security;
using System.Threading.Tasks;
namespace Framework.Repository
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {

        protected readonly DbContext _context;
        protected readonly DbSet<TEntity> _entities;

        public Repository(DbContext context)
        {
            _context = context;
            _entities = context.Set<TEntity>();
        }




        public virtual void Add(TEntity instance)
        {

            IEntity<Guid> entity = instance as IEntity<Guid>;
            if (entity != null)
            {
                if (entity.ID == Guid.Empty)
                {
                    entity.ID = Guid.NewGuid();
                }
            }
            _entities.AddRange(instance);

        }


        public virtual void Save(TEntity instance)
        {
           
            //_entities.Add(instance);


            if (_context.Entry(instance).State == EntityState.Detached)
            {
                IEntity<Guid> entity = instance as IEntity<Guid>;
                if (entity != null)
                {
                    if (entity.ID == Guid.Empty)
                    {
                        entity.ID = Guid.NewGuid();
                    }
                }
                _entities.Add(instance);
            }
            else
            {
                _entities.Update(instance);
            }

        }








        public virtual void Remove(TEntity instance)
        {
            _entities.Remove(instance);

        }


        public void Remove(IEnumerable<TEntity> predicate)
        {
            _entities.RemoveRange(predicate);
        }


        public virtual TEntity One(
            Expression<Func<TEntity, bool>> predicate = null,
            params Expression<Func<TEntity, object>>[] includes)
        {
            var set = CreateIncludedSet(includes);

            return (predicate == null) ?
                   set.FirstOrDefault() :
                   set.FirstOrDefault(predicate);
        }


        public virtual Task<TEntity> OneAsync(Expression<Func<TEntity, bool>> predicate = null, params Expression<Func<TEntity, object>>[] includes)
        {
            var set = CreateIncludedSet(includes);

            return (predicate == null) ?
                   set.FirstOrDefaultAsync() :
                   set.FirstOrDefaultAsync(predicate);
        }



        public virtual IQueryable<TEntity> Where(
            Expression<Func<TEntity, bool>> predicate = null,
            params Expression<Func<TEntity, object>>[] includes)
        {
            var set = CreateIncludedSet(includes);

            return (predicate == null) ? set.AsQueryable() : set.Where(predicate).AsQueryable();
        }

        public IQueryable<TEntity> Query
        {

            get
            {
                return this._entities.AsQueryable();
            }
        }


        public virtual bool Exists(
            Expression<Func<TEntity, bool>> predicate = null)
        {


            return (predicate == null) ? _entities.Any() : _entities.Any(predicate);
        }


        public virtual Task<bool> ExistsAsync(Expression<Func<TEntity, bool>> predicate = null)
        {


            return (predicate == null) ? _entities.AnyAsync() : _entities.AnyAsync(predicate);
        }


        public virtual int Count(
            Expression<Func<TEntity, bool>> predicate = null)
        {

            return (predicate == null) ?
                _entities.Count() :
                _entities.Count(predicate);
        }


        public virtual Task<int> CountAsync(Expression<Func<TEntity, bool>> predicate = null)
        {

            return (predicate == null) ?
                _entities.CountAsync() :
                _entities.CountAsync(predicate);
        }


        private DbSet<TEntity> CreateIncludedSet(
            IEnumerable<Expression<Func<TEntity, object>>> includes)
        {


            if (includes != null)
            {
                foreach (var include in includes)
                {
                    _entities.Include(include);
                }
            }

            return _entities;
        }


    }
}
