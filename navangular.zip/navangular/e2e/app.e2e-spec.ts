import { PromosharePage } from './app.po';

describe('promoshare App', () => {
  let page: PromosharePage;

  beforeEach(() => {
    page = new PromosharePage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
