import { Component } from '@angular/core';

@Component({
  // tslint:disable-next-line
  selector: 'body',
  template: '<alert></alert><router-outlet></router-outlet>'
})
export class AppComponent { }
