import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthenticationService } from '../../shared/index';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html'
})
export class AppHeaderComponent implements OnInit, OnDestroy {

  status: boolean;
 subscription: Subscription;

  constructor(private authenticationService: AuthenticationService) {
   }

   logout() {
     this.authenticationService.logout();
  }

  ngOnInit() {
    this.subscription = this.authenticationService.authNavStatus$.subscribe(status => this.status = status);
  }

   ngOnDestroy() {
    // prevent memory leak when component is destroyed
    this.subscription.unsubscribe();
  }
}
