import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar-form',
  templateUrl: './app-sidebar-form.component.html'
})
export class AppSidebarFormComponent { }
