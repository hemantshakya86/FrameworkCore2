import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { JwtHelper } from 'angular2-jwt';
import { AuthenticationService } from '../services/authentication.service';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';


@Injectable()
export class AuthGuard implements CanActivate, OnInit {
  jwtHelper: JwtHelper = new JwtHelper();
  constructor(private router: Router, private authenticationService: AuthenticationService) {
  }
  ngOnInit() {
  }
  canActivate() {
    if (this.authenticationService.isTokenExpired()) {
      console.log(this.authenticationService.isTokenExpired(), this.authenticationService.isLoggedIn());
      this.router.navigate(['/login']);
      return false;
   }
    if (!this.authenticationService.isLoggedIn()) {
       this.router.navigate(['/login']);
       return false;
    }
    return true;
  }
}
