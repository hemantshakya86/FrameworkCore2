﻿export class ChangePasswordModel {
    oldPassword: string;
    newPassword: string;
    repeatPassword: string;
}
