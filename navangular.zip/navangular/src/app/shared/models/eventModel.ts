export class EventModel {
    ID: number;
    Address: string;
    City: string;
    // CreateDate: string;
    // DasboardImage: string;
    EventEndDate: string;
    // EventManagerEmail: string;
    // EventManagerName: string;
    // EventManagerProfilePic: string;
    EventStartDate: string;
    // LandingPageImage: string;
    // logo: string|any;
    Name: string;
    UniqueUrl: string;
    ZipCode: string;
// constructor( id: number,
//     address: string,
//     city: string,
//     createDate: string,
//     dasboardImage: string,
//     eventEndDate: string,
//     eventManagerEmail: string,
//     eventManagerName: string,
//     eventManagerProfilePic: string,
//     eventStartDate: string,
//     landingPageImage: string,
//     logo: string,
//     name: string,
//     uniqueUrl: string,
//     zipCode: string) {
//         this.address = address;
//         this.city = city;
//         this.createDate = createDate;
//         this.dasboardImage = dasboardImage;
//         this.eventEndDate = eventEndDate;
//         this.eventManagerEmail = eventManagerEmail;
//         this.eventManagerName = eventManagerName;
//         this.eventManagerProfilePic = eventManagerProfilePic;
//         this.eventStartDate = eventStartDate;
//         this.landingPageImage = landingPageImage;
//         this.logo = logo;
//         this.name = name;
//         this.uniqueUrl = uniqueUrl;
//         this.zipCode = zipCode;
// }

}
