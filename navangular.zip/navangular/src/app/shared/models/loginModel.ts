﻿export class LoginModel {
    userName: string;
    password: string;
    rememberMe: boolean;
}
