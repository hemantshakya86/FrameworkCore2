export class RewardModel{
    ID: number;
    Description: string;
    PointNeeded: number;
    Priority: number;
    
}