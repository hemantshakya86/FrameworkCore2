export class TicketModel {
    ID: number;
    EventID: number;
    Title: string;
    Description: string;    
    Price: DoubleRange;    
    Quantity: number;
    QuantityInHand: number;
    Points: number;   
    
}
