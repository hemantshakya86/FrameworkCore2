﻿export class User {
    id: number;
    email: string;
    password: string;
    repeatPassword: string;
    firstName: string;
    lastName: string;
    fullName: string;
    companyName: string;
    navUrl: string;
}
