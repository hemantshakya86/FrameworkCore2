import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { User } from '../models/index';
import { JwtHelper } from 'angular2-jwt';
import { LoginModel } from '../models/loginModel';
import { BehaviorSubject } from 'rxjs/Rx';
@Injectable()
export class AuthenticationService {
  isTokenExpire: boolean;
 // Observable navItem source
 private _authNavStatusSource = new BehaviorSubject<boolean>(false);
 // Observable navItem stream
 authNavStatus$ = this._authNavStatusSource.asObservable();

 private loggedIn = false;
  jwtHelper: JwtHelper = new JwtHelper();


  constructor(private http: Http) {
    this.loggedIn = !!localStorage.getItem('auth_token');
    // ?? not sure if this the best way to broadcast the status but seems to resolve issue on page refresh where auth status is lost in
    // header component resulting in authed user nav links disappearing despite the fact user is still logged in
    this._authNavStatusSource.next(this.loggedIn);
  }

  login(userLogin: LoginModel) {
    const objectToSend = JSON.stringify(userLogin);
    console.log(objectToSend);
     const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    // tslint:disable-next-line:max-line-length
    return this.http.post('http://localhost:52588/api/auth/login', objectToSend, { headers: headers })
      .map((response: Response) => {
        // login successful if there's a jwt token in the response

        const response_token = response.json();
        console.log(response_token);
        const accessToken = response_token.auth_token;

        if (accessToken == null) {
          throw new Error('Received accessToken was empty');
        }

       // let refreshToken: string = response_token.refresh_token;
        const expiresIn: number = response_token.expires_in;

        const tokenExpiryDate = new Date();
        tokenExpiryDate.setSeconds(tokenExpiryDate.getSeconds() + expiresIn);

        const accessTokenExpiry = tokenExpiryDate;
        localStorage.setItem('auth_token', response_token.auth_token);
        localStorage.setItem('id', response_token.id);
        this.loggedIn = true;
        this._authNavStatusSource.next(true);
        return true;
       // return accessToken;

      });
  }
  isTokenExpired() {
    const token = localStorage.getItem('auth_token');
    if (token) {
    this.isTokenExpire = this.jwtHelper.isTokenExpired(token);
    }

    console.log(this.isTokenExpire);
    if (this.isTokenExpire) {
      return true;
    }
    return false;
  }
  logout() {
    localStorage.removeItem('auth_token');
    this.loggedIn = false;
    this._authNavStatusSource.next(false);
  }

  isLoggedIn() {
    return this.loggedIn;
  }


  useJwtHelper() {
    const token = localStorage.getItem('auth_token');
    const tokenData = JSON.parse(token);
    return this.jwtHelper.decodeToken(token);

  }
}
