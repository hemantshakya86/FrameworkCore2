import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { EventModel } from '../models/eventModel';
import { TicketModel } from '../models/ticketModel';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class EventService {

     public appURL = 'http://localhost:52588';
     selectedEvent: EventModel= new EventModel();
     selectedTicket: TicketModel= new TicketModel();
     constructor(private http: Http) {}
     getAll() {
        return this.http.get(this.appURL + '/api/EventManage/GetAllEvents', this.jwt()).map((response: Response) => response.json().Items);
     }

    postEvent(event: EventModel) {
      
      var body= JSON.stringify(event);
      return this.http.post(this.appURL + '/api/EventManage/SaveEvent', body, this.jwt())
      
    }

    getTicket(ticketID) {
      return this.http.get(this.appURL + '/api/EventManage/GetTicket/'+ ticketID,  this.jwt())
      .map(x=>x.json().items);
    
      
    }

  getAllTicket(eventID:number) {
    return this.http.get(this.appURL + '/api/EventManage/GetAllTickets/'+eventID, this.jwt()).map((response: Response) => response.json().Items);
  }
  postTicket(ticket: TicketModel, eventID:number) {
    ticket.ID=0;
    var body= JSON.stringify(ticket);
    console.log(ticket);
    return this.http.post(this.appURL + '/api/EventManage/AddTicket/' + eventID, body, this.jwt());
  }
  putTicket(ticketID, TicketModel) {
    var body= JSON.stringify(TicketModel);

    return this.http.put(this.appURL + '/api/EventManage/UpdateTicket/'+ticketID, body, this.jwt())
   }

  deleteTicket(ticketID:number) {
 
    return this.http.delete(this.appURL + '/api/EventManage/DeleteTicket/'+ ticketID, this.jwt());
    
  }



  deleteEvent(eventID:number) {
 
    return this.http.delete(this.appURL + '/api/EventManage/DeleteEvent/'+ eventID, this.jwt());
    
  }
  putEvent(eventID, EventModel) {
    var body= JSON.stringify(EventModel);    
    return this.http.put(this.appURL + '/api/EventManage/UpdateEvent/'+eventID, body, this.jwt())
   }


    private jwt() {
        // create authorization header with jwt token
        const token = localStorage.getItem('auth_token');
        if (token) {
          var headerOption=new Headers();
          headerOption.append('Content-Type','application/json');
          headerOption.append('Authorization','Bearer ' + token)
          return new RequestOptions({ headers: headerOption });
        }
      }
}
