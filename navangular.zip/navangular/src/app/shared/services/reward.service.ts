import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { RewardModel } from '../models/rewardModel';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';


@Injectable()
export class RewardService {

    public appURL = 'http://localhost:52588';
    model: RewardModel= new RewardModel();
    constructor(private http: Http) {}
    getAllRewards(eventID:number) {
      return this.http.get(this.appURL + '/api/EventManage/GetAllRewards/'+eventID, this.jwt()).map((response: Response) => response.json().Items);
  }
postReward(model: RewardModel, eventID:number) {
      model.ID=0;
      var body= JSON.stringify(model);
      return this.http.post(this.appURL + '/api/EventManage/SaveReward/' + eventID, body, this.jwt())        
}

getReward(rewardID) {
  return this.http.get(this.appURL + '/api/EventManage/GetReward/'+ rewardID,  this.jwt())
  .map(x=>x.json().Items);

  
}
putReward(rewardID, model) {
  var body= JSON.stringify(model);
  return this.http.put(this.appURL + '/api/EventManage/UpdateReward/'+rewardID, body, this.jwt()) }

deleteReward(rewardID:number) {
 
  return this.http.delete(this.appURL + '/api/EventManage/DeleteReward/'+ rewardID, this.jwt());
  
}
private jwt() {
    // create authorization header with jwt token
    const token = localStorage.getItem('auth_token');
    if (token) {
      var headerOption=new Headers();
      headerOption.append('Content-Type','application/json');
      headerOption.append('Authorization','Bearer ' + token)
      return new RequestOptions({ headers: headerOption });
    }
  }


}