import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { User } from '../models/user';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { ChangePasswordModel } from '../models/changePasswordModel';

@Injectable()
export class UserService {
  public appURL = 'http://localhost:52588';
  model: User = new User();
  changePasswordModel: ChangePasswordModel = new ChangePasswordModel();
  constructor(private http: Http) {}
  userGet() {
    const id = localStorage.getItem('id');
    console.log(id);
     return this.http.get(this.appURL + '/api/accounts/' + id, this.jwt()).map((response: Response) => response.json());
 }

 createUser(model: User) {
   const body = JSON.stringify(model);
   console.log(model, body);
   return this.http.post(this.appURL + '/api/accounts', body, this.mediaType());
}


putAgent(model: User) {
  const body = JSON.stringify(model);
  return this.http.put(this.appURL + '/api/accounts', body, this.jwt());
}

changePassword(changePasswordModel: ChangePasswordModel) {
  console.log(changePasswordModel);
  const body = JSON.stringify(changePasswordModel);
  return this.http.post(this.appURL + '/api/Manage/ChangePassword', body, this.jwt());
}
// deleteAgent(agentID:number) {
//  console.log(agentID)
//   return this.http.delete(this.appURL + '/api/ManageAgent/DeleteAgent/'+ agentID, this.jwt());
// }

  // private helper methods

  private jwt() {
    // create authorization header with jwt token
    const token = localStorage.getItem('auth_token');
    if (token) {
      const headerOption = new Headers();
      headerOption.append('Content-Type', 'application/json');
      headerOption.append('Authorization', 'Bearer ' + token);
      return new RequestOptions({ headers: headerOption });
    }
  }
  private mediaType() {
    const headerOption = new Headers();
    headerOption.append('Content-Type', 'application/json');
    return new RequestOptions({ headers: headerOption });
  }
}
