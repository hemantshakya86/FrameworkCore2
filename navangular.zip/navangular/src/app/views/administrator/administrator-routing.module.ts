import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
// import { RewardsComponent } from './rewards/rewards.component';
// import { RewardListComponent } from './reward-list/reward-list.component';
const routes: Routes = [
  {
    path: '', data: {
      title: 'Administrator'
    },
        children: [
          {
            path: 'users/users',
            component: UsersComponent,
            data: {
              title: 'Users'
            }
          },
          {
            path: 'users/changepassword',
            component: ChangePasswordComponent,
            data: {
              title: 'Change Password'
            }
          },
        ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministratorRoutingModule { }
