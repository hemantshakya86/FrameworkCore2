import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdministratorRoutingModule } from './administrator-routing.module';
import { UsersComponent } from './users/users.component';
// import { RewardsComponent } from './rewards/rewards.component';
 import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
// import { RewardListComponent } from './reward-list/reward-list.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DisplayErrorComponent } from '../display-error/display-error.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { ChangePasswordComponent } from './change-password/change-password.component';
@NgModule({
  imports: [
    CommonModule,
    AdministratorRoutingModule,
    ModalModule.forRoot(),
    ReactiveFormsModule,
    FormsModule,
    NgxPaginationModule,
  ],
    declarations: [UsersComponent, ChangePasswordComponent, DisplayErrorComponent ]
})
export class AdministratorModule { }
