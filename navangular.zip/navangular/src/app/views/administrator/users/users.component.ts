import { Component, OnInit, AfterViewInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal/modal.component';
import { UserService } from '../../../shared/index';
import { User } from '../../../shared/models/user';
import { NgForm } from '@angular/forms';
import { AlertService } from '../../../shared/services';
import { Router } from '@angular/router';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  @ViewChild('AgentPopUp')
  AgentPopUp: ModalDirective;
  users: User[];
  userModel: User = new User();
  // @ViewChild('fileInput') fileInput: ElementRef;
 // constructor(private userService: UserService, private alertService: AlertService) {}
   constructor(private userService: UserService, private alertService: AlertService, private router:Router) { }
  public myModal;
  ngOnInit() {
    this.userService.userGet().subscribe(res => {this.userModel = res; });
  }

  // saveAgent(agentForm) {
  //  console.log(agentForm.value);
  //   if(agentForm.value.id == null){
  //     this.userService.postAgent(agentForm.value)
  //     .subscribe(data => {
  //       this.resetForm(agentForm);
  //       this.AgentPopUp.hide();
  //        setTimeout(()=>{
  //        // this.router.navigate(['/administrator/users/users']);
  //        this.alertService.success('Agent saved successfully.');

  //         this.userService.getAll().subscribe(res => {this.users = res; });
          
  //         },500);
  //     }, error => {
  //       this.alertService.error(error._body);
  //     }
  //   );
  //   }


  //   else{
  //       this.userService.putAgent(agentForm.value)
  //   .subscribe(data => {
  //     this.resetForm(agentForm);
  //     this.AgentPopUp.hide();
  //      setTimeout(()=>{
  //      // this.router.navigate(['/administrator/users/users']);
  //      this.alertService.success('Agent updated successfully.');

  //       this.userService.getAll().subscribe(res => {this.users = res; });
  //       },500);
  //   }, error => {
  //     this.alertService.error(error._body);
  //   }
  // );
  //   }
  //   }

  updateAgent(agentForm) {
    this.userService.putAgent(agentForm.value)
      .subscribe(data => {
        this.resetForm(agentForm);
        this.AgentPopUp.hide();
         setTimeout(() => {
         // this.router.navigate(['/administrator/users/users']);
         this.alertService.success('Agent updated successfully.');
         this.userService.userGet().subscribe(res => {this.userModel = res; });
          }, 500);
      }, error => {
        this.alertService.error(error._body);
      }
    );
  }
  editAgent(user: User) {
    this.userService.model = Object.assign({}, user);
   this.AgentPopUp.show();
        }
  resetForm(form?: NgForm) {
    form.reset();
  }


  // deleteAgent(id:number){
  //   if(confirm('Are you sure to delete this record?') ==  true){
  //    this.userService.deleteAgent(id).subscribe(x=> {
  //     this.userService.getAll().subscribe(res => {this.users = res;
  //       this.alertService.success('Agent Deleted successfully.');
  //     });
  //    });
  //   } }

}
