import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService, AlertService, UserService } from '../../shared/index';
import { LoginModel } from '../../shared/models/loginModel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
model= new LoginModel();
  loading = false;
  returnUrl: string;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
     private userService: UserService, private alertService: AlertService) { }

  ngOnInit() {
    this.authenticationService.logout();
  }
login(model) {
  this.model.rememberMe = true;
      this.loading = true;
          this.authenticationService.login(this.model)
        .subscribe(
        data => {
          if (data) {
            this.router.navigate(['/dashboard']);
          }
        },
        error => {
          this.alertService.error(error._body);
          this.loading = false;
        });
    }
     register() {
       this.router.navigate(['/pages/register']);
     }
}
