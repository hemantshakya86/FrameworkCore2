import { Component, OnInit, AfterViewInit, OnDestroy, ElementRef, ViewChild, TemplateRef } from '@angular/core';
import { EventService } from '../../../shared/index';
import {NgForm} from '@angular/forms';
import { EventModel } from '../../../shared/models/eventModel';
import { Router } from '@angular/router';
import { AlertService } from '../../../shared/services';
import { ModalDirective } from 'ngx-bootstrap/modal/modal.component';
import { TicketModel } from '../../../shared/models/ticketModel';
import { RewardService } from '../../../shared/index';
import { RewardModel } from '../../../shared/models/rewardModel';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
// declare var jQuery: any;
@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss'],
})
export class EventComponent implements OnInit {
  public myModal;
  @ViewChild('ticketModal') ticketModal:ModalDirective;
  @ViewChild('rewModal')  rewModal:ModalDirective;
  tickets: TicketModel[];
  form: NgForm;
  router: Router;
  rewards: RewardModel[];

  rewardform: FormGroup;

  @ViewChild('fileInput') fileInput: ElementRef;
  constructor(private formBuilder: FormBuilder,private eventService: EventService,private rewardService: RewardService,  private alertService: AlertService) {}
  ngOnInit() {

    this.rewardform = this.formBuilder.group({
      ID:[null],
      Description: [null, Validators.required],
       PointNeeded: [null, [Validators.required]],
       Priority: [null, [Validators.required]],
     });
   
    if(this.eventService.selectedEvent.ID !=null){
      this.eventService.getAllTicket(this.eventService.selectedEvent.ID).subscribe(res => {this.tickets = res; });
      this.rewardService.getAllRewards(this.eventService.selectedEvent.ID).subscribe(res => {this.rewards = res; });
    
    }
  
  }

  isFieldValid(field: string) {
    return !this.rewardform.get(field).valid && this.rewardform.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
 

  saveReward() {

 
    if (this.rewardform.valid) {
        this.rewardService.postReward(this.rewardform.value, this.eventService.selectedEvent.ID)
      .subscribe(data => {
        this.alertService.success('Reward saved successfully.');
        this.resetRewardForm();
       this.rewModal.hide();
         setTimeout(()=>{
         
          this.rewardService.getAllRewards(this.eventService.selectedEvent.ID).subscribe(res => {this.rewards = res; });
          this.alertService.clear();
        
        },1500)
          
      }, error => {
        this.alertService.error(error._body);
      }
    );
 
        
    } else {
      this.validateAllFormFields(this.rewardform);
    }
   
    
  }
  updateReward() {
    if (this.rewardform.valid) {
        this.rewardService.putReward(this.rewardform.value.ID,this.rewardform.value)
        .subscribe(data => {
          this.alertService.success('Reward updated successfully.');
      
          setTimeout(()=>{
            this.resetRewardForm();
            this.rewModal.hide();
            this.rewardService.getAllRewards(this.eventService.selectedEvent.ID).subscribe(res => {this.rewards = res; });
            this.alertService.clear();
        },1500);
        }, error => {
          this.alertService.error(error._body);
        }
      );
 
    }
     else {
      this.validateAllFormFields(this.rewardform);
    }
   
    
  }

  resetRewardForm() {
    this.rewardform.reset();

  }

  editReward(rew:RewardModel){
    this.rewardService.model = Object.assign({}, rew);
 
       this.rewModal.show();
     }
     deleteReward(id:number){
       if(confirm('Are you sure to delete this record?') ==  true){
        this.rewardService.deleteReward(id).subscribe(x=> {
          this.alertService.success('Reward has been deleted successfully.');
         this.rewardService.getAllRewards(this.eventService.selectedEvent.ID).subscribe(res => {this.rewards = res; });
        })
         
       }
      }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  showRewardModal(){
    this.resetRewardForm();
    this.rewModal.show();

  }
  back() {
    this.resetRewardForm();
    this.rewModal.hide();
  }

  editTicket(tic:TicketModel){
    console.log(tic)
     this.eventService.selectedTicket = Object.assign({}, tic);
    // this.router.navigate(['/administrator/rewards'])
    this.ticketModal.show();
       
     }

     deleteTicket(id:number){
      if(confirm('Are you sure to delete this record?') ==  true){
       this.eventService.deleteTicket(id).subscribe(x=> {
        
        this.eventService.getAllTicket(this.eventService.selectedEvent.ID).subscribe(res => {this.tickets = res; });
  
       })
        
      } }

  onSubmit(eventForm: NgForm) {
    if(eventForm.value.id==null)
    {    
    this.eventService.postEvent(eventForm.value)
    .subscribe(data => {
      this.alertService.success('Event save successfully.');
       // this.router.navigate(['/dashboard']);
    }, error => {
      this.alertService.error(error._body);
    }
  );
}
else{
  this.eventService.putEvent(eventForm.value.id,eventForm.value)
   .subscribe(data => {
    this.resetForm(eventForm);    
    //  setTimeout(()=>{
     
    //   this.eventService.getAllTicket().subscribe(res => {this.tickets = res; });
       
    //   },500);
   }, error => {
     
    this.alertService.error(error._body);
   });  
}
  }

  onTicketSave(form: NgForm) {
    if(form.value.id == null){    
    this.eventService.postTicket(form.value,this.eventService.selectedEvent.ID)
    .subscribe(data => {
      this.alertService.success('Ticket save successfully.');

      this.resetForm(form);
      this.ticketModal.hide();
        setTimeout(()=>{
        
         this.eventService.getAllTicket(this.eventService.selectedEvent.ID).subscribe(res => {this.tickets = res; });
         this.alertService.clear();
       
       },1500)


       // this.router.navigate(['/dashboard']);
    }, error => {
      this.alertService.error(error._body);
    }
  );
}
else{
  this.eventService.putTicket(form.value.id,form.value)
   .subscribe(data => {
    this.resetForm(form);
    this.ticketModal.hide();
     setTimeout(()=>{
     
      this.eventService.getAllTicket(this.eventService.selectedEvent.ID).subscribe(res => {this.tickets = res; });
       
      },500);
   }, error => {
     
    this.alertService.error(error._body);
   });  
 }
}



  onFileChange(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      console.log(file);
      reader.readAsDataURL(file);
      reader.onload = () => {
        console.log(reader.result.split(',')[1]);
        // this.form.('avatar').setValue({
        //   filename: file.name,
        //   filetype: file.type,
        //   value: reader.result.split(',')[1]
        // })
      };
    }
  }
  // reset(form?: NgForm) {
  //   if (form != null) {
  //   form.reset();
  //   }
  //   this.eventService.selectedEvent = {
  //     Address: '',
  //     City: '',
  //     EventEndDate: '',
  //     EventStartDate: '',
  //     Name: '',
  //     UniqueUrl: '',
  //     ZipCode: '',
  //     Logo: ''
  //   };
  // }

  resetForm(form?: NgForm) {

    form.reset();
 
  }
  
}
