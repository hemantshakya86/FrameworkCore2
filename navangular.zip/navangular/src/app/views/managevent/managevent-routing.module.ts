import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageventComponent } from './managevent.component';
import { EventComponent } from './event/event.component';

const routes: Routes = [
  // {
  //   path: '', component: ManageventComponent
  //       // children: [
  //       //   {
  //       //     path: 'users/users',
  //       //     component: UsersComponent,
  //       //     data: {
  //       //       title: 'Users'
  //       //     }
  //       //   }
  //       // ]
  // }
  {
    path: '', component: ManageventComponent, data: {
      title: 'ManagEvent'
    },
        // children: [
        //   {
        //     path: 'event/event',
        //     component: EventComponent,
        //     data: {
        //       title: 'Event'
        //     }
        //   }
        // ]
  },
  {
    path: 'event', component: EventComponent, data: {
      title: 'Event'
    },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageventRoutingModule { }
