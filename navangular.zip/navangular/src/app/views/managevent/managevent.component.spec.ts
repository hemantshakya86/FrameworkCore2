import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageventComponent } from './managevent.component';

describe('ManageventComponent', () => {
  let component: ManageventComponent;
  let fixture: ComponentFixture<ManageventComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageventComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
