import { Component, OnInit } from '@angular/core';
import { EventService } from '../../shared/services/event.service';
import { EventModel } from '../../shared/models/eventModel';
import { Router } from '@angular/router';
@Component({
  selector: 'app-managevent',
  templateUrl: './managevent.component.html',
  styleUrls: ['./managevent.component.scss']
})
export class ManageventComponent implements OnInit {
  events: EventModel[];
   constructor(private eventService: EventService, private router:Router) { }

  ngOnInit() {
    this.eventService.getAll().subscribe(res => {this.events = res; });
   
  }
  editEvent(event1:EventModel){
    this.eventService.selectedEvent = Object.assign({}, event1);

    this.router.navigate(['/managevent/event'])
     
     }
     deleteEvent(id:number){
      if(confirm('Are you sure to delete this record?') ==  true){
       this.eventService.deleteEvent(id).subscribe(x=> {
        
        this.eventService.getAll().subscribe(res => {this.events = res; });
  
       })
        
      } }


     showEvent(){
      this.eventService.selectedEvent = {

          ID:null,
            Address: '',
            City: '',
            EventEndDate: '',
            EventStartDate: '',
            Name: '',
            UniqueUrl: '',
            ZipCode: '',
           // logo: ''
           };

      this.router.navigate(['/managevent/event'])
    }
}
