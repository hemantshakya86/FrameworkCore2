import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ManageventComponent} from './managevent.component';
import { ManageventRoutingModule } from './managevent-routing.module';
import { EventComponent } from './event/event.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { EventService } from '../../shared/index';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import {NgxPaginationModule} from 'ngx-pagination';
import { ReactiveFormsModule } from '@angular/forms';

import { DisplayErrorComponent } from '../display-error/display-error.component';
@NgModule({
  imports: [
    CommonModule,
    ManageventRoutingModule,
    TabsModule,
    ModalModule.forRoot(),
    FormsModule,
    NgxPaginationModule,
    ReactiveFormsModule,
  ],
  declarations: [ManageventComponent, EventComponent,DisplayErrorComponent],

})
export class ManageventModule { }
