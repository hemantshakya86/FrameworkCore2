import { Component } from '@angular/core';
import { User } from '../../shared/models';
import { UserService, AlertService } from '../../shared';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  templateUrl: 'register.component.html',
})
export class RegisterComponent {

  users: User[];

   constructor(private userService: UserService, private alertService: AlertService, private router: Router) { }
   createUser(agentForm) {
    console.log(agentForm.value);
    this.userService.createUser(agentForm.value)
    .subscribe(data => {
       setTimeout(() => {
         this.resetForm(agentForm);
       this.alertService.success('User create successfully.');
       this.router.navigate(['/login']);

        }, 500);
    }, error => {
      this.alertService.error(error._body);
    }
  );
     }
     resetForm(form?: NgForm) {
        form.reset();
      }
}
